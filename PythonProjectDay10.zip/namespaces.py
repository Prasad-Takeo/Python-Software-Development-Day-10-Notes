# """
# namespace and its scope
#
# is a collection of defined symbolic names along with information
# about the object that each name reference.
# """
#
# a = 10 #global namespace
# print("outside function",a,id(a)) #output: 10
#
# def print_a_local(a):
#     print("within function",a,id(a)) #local 10
#     a = 100 #local 100 -> never change the global a
#     print("within function",a,id(a)) #local 100
#
# print_a_local(a) #output:10 100
# print("outside function",a,id(a)) #output: 10
#
# def print_a_global():
#     global a
#     print("within function",a,id(a))
#     a = 100
#     print("within function",a,id(a))
#
# print_a_global() #output: 10 100
# print("outside function",a) #output: ? 100
#
# """
# four types of namespaces
# 1. Built-in
# 2. Global
# 3. Enclosing
# 4. Local
# """
# #built-in namespace contains the names of all of python's built in objects
# #available at all times when Python is running
# from pprint import pprint
# pprint(dir(__builtins__))
#
# #global namespace
# #contains any names defined at the top level of the main program
# #python creates the global namespace when the main program body starts and it remains
# #existence until the interpreter terminates
# name = "sugumar"
#
# #local and enclsoing namespace
# ## whenever the function executes, the interpreter creates a new namespace,
# # this namespace is local to the function and remains in existence
# #until the function terminates
#
# def f():
#     i = 10
#     print('start f()')
#
#     def g(): #enclosing namespace
#         print(i) #f's namespace is shared with g() but g's namespace is not shared with f()
#         j  = 100
#         print("start g()")
#         print("end g()")
#         return
#
#     g()
#     # print(j)
#
#     print("End f()")
#     return
#
# f()
# """
# When the main program calls f(), python creates a new namespace for f().
# similarly, when f() calls g(), g() get it's own separate namespace.
# The namespace created for g() is the local namespace, while the namespace create for
# f() is the enclosing namespace
#
# Each of these namespace remains in existence until it's respective function terminates.
# """
#
#
# #varibles scope
# #local, enclosing, global, builtin - LEGB rule
# # interpreter searches for a name from the inside out, looking in local, enclosing,global and finally the builtin
#
# #single definition of a variable
# x = "global"
# def myfunc1():
#     def myinnerfunc1():
#         print(x)
#     myinnerfunc1()
# myfunc1() #-> global
#
# #double definition
# p = "global"
# def myfunc2():
#     p = "enclosing"
#     def myinnerfunc2():
#         print(p)
#     myinnerfunc2()
# myfunc2() #output - enclosing
# #line 92 defines p in the global scope
# #line 94 defines p again in the enclosing scope
#
# #triple definition
# q = "global"
# def myfunc3():
#     q = "enclosing"
#     def myinnerfunc3():
#         q = "local"
#         print(q)
#     myinnerfunc3()
# myfunc3() #output -> local
# #line 103 defines q in the global scope
# #line 105 defines q in the enclosing scope
# #line 107 defines q again in the scope that's local to myinnerfunc3
#
# #x = 100
# # def f():
# #     def g():
# #           x = 1000
# #           print(x)
# #     g()
# # f()
#
# #modify variables out of scop
# #an immutable argument can never be modified by a function
# v = 20
# def v1():
#     v = 40
#     print(v)
# v1() # --> 40
# print(v) # -- > 20
# #a mutable argument can't be redefined wholesale, but it can be modified in place
# l1 = ["a","b","c"]
# def v2():
#     l1[2] = "d"
# v2()# -- >
# print(l1) # --> [a,b,d]
# print(id(l1))
#
# l2  = ["sugumar","course","bootcamp"]
# def v3():
#     l2 = ["test","Test1"]
# v3()
# l2
#LEGB
# x = 20
# def f():
#     x = 10
#     def g():
#        print(x) #--> 10
#     g()
#     print(x) #--> 10
# f()
# print(x) #--> 20

#since x is the enclosing scope, not the global scope, the global keyword doesn't work here.
#after g() terminates, x in the enclosing space remains 20

#in the above example, x statement not only fails to provide access to the x in the enclosing scope,
#but it also creates an new object called x in the global scope whose value is 40